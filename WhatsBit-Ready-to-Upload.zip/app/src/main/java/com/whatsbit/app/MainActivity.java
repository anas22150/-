package com.whatsbit.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.*;
import android.content.res.ColorStateList;

public class MainActivity extends Activity {
    private LinearLayout messages;
    private final int green = Color.rgb(18, 140, 90);

    private GradientDrawable bubbleBg(int color) {
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(color);
        bg.setCornerRadius(24);
        return bg;
    }

    private TextView makeText(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private void addMessage(String value, boolean mine) {
        TextView bubble = makeText(value, 16, Color.rgb(30, 30, 30));
        bubble.setPadding(24, 16, 24, 16);
        bubble.setBackground(bubbleBg(mine ? Color.rgb(220, 248, 198) : Color.WHITE));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.gravity = mine ? Gravity.RIGHT : Gravity.LEFT;
        lp.setMargins(8, 8, 8, 8);
        messages.addView(bubble, lp);
    }

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(240, 242, 245));

        LinearLayout header = new LinearLayout(this);
        header.setOrientation(LinearLayout.VERTICAL);
        header.setPadding(20, 18, 20, 18);
        header.setBackgroundColor(green);
        TextView title = makeText("WhatsBit", 26, Color.WHITE);
        title.setTypeface(null, Typeface.BOLD);
        header.addView(title);
        header.addView(makeText("نسخة تجريبية • الرسائل محلية فقط", 13, Color.WHITE));
        root.addView(header);

        TextView note = makeText(
            "أهلًا بك! دي نسخة أولية للتجربة. الرسائل بين أجهزة مختلفة ومشاركة الموقع تحتاج خادمًا وحسابات وموافقة واضحة من المستخدم.",
            14, Color.rgb(80, 70, 35));
        note.setPadding(16, 12, 16, 12);
        note.setBackgroundColor(Color.rgb(255, 248, 220));
        root.addView(note);

        ScrollView scroll = new ScrollView(this);
        messages = new LinearLayout(this);
        messages.setOrientation(LinearLayout.VERTICAL);
        messages.setPadding(8, 12, 8, 12);
        scroll.addView(messages);
        root.addView(scroll, new LinearLayout.LayoutParams(-1, 0, 1));

        addMessage("أهلًا! دي محادثة تجريبية على نفس الجهاز.", false);
        addMessage("تمام، خلّينا نجرب التطبيق.", true);

        LinearLayout composer = new LinearLayout(this);
        composer.setPadding(10, 8, 10, 8);
        composer.setGravity(Gravity.CENTER_VERTICAL);
        composer.setBackgroundColor(Color.WHITE);
        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("اكتب رسالة تجريبية...");
        composer.addView(input, new LinearLayout.LayoutParams(0, -2, 1));
        Button send = new Button(this);
        send.setText("إرسال");
        send.setTextColor(Color.WHITE);
        send.setBackgroundTintList(ColorStateList.valueOf(green));
        composer.addView(send);
        send.setOnClickListener(v -> {
            String value = input.getText().toString().trim();
            if (!value.isEmpty()) {
                addMessage(value, true);
                input.setText("");
                Toast.makeText(this, "رسالة تجريبية على الشاشة فقط", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(composer);
        setContentView(root);
    }
}
